#ifndef ARRAYEXCEPTION_HPP
#define ARRAYEXCEPTION_HPP
class ArrayException {
	
	public:
		virtual std::string GetMessage() = 0; //make abstract

};
#endif

