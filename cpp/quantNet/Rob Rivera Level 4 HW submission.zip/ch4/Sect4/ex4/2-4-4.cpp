/*
Level 4, Sect 4, Ex 2
Author Rob Rivera
Date 9-21-2016

*/

#include <iostream>
#include "Point.hpp"
#include "Circle.hpp"
#include "Line.hpp"

using namespace std;
int main() {
	// initialization
	
	Point p = Point(1.0,1.0);
	cout << p << endl;
	
	return 0;

}
