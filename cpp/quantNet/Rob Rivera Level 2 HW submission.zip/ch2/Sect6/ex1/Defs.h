#ifndef DEFS_H
#define DEFS_H

#define PRINT1(x) printf("%d\n", x);

#define PRINT2(x,y) printf("%d %d\n", x, y);


#endif
