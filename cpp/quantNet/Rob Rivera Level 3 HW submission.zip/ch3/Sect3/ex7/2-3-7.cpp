/*
Level 3, Sect 3, Ex 7
Author Rob Rivera
Date 9-17-2016

*/

#include <iostream>
#include "Point.hpp"

using namespace std;
int main() {
	// initialization

	Point pt1 = Point(14, -14);
	Point pt2 = Point();



	return 0;

}
