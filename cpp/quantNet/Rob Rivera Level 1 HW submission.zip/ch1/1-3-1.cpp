/*
Title: Level 1, S 3, Ex 1
Author: Rob Rivera
Date: 9/9/2016
printf() is a standard function. Each compiler will support this function. Between the () is statted what has to be printed (on screen). Create a C-program that prints the followin when executed:

	My first C-program
	is a fact!
	Good, isn't it?
*/
#include <stdio.h>//import the standard io library. 

int main() {

	printf("My first C-program!\nis a fact!\nGood, isn't it?\n");
	return 0;
}
